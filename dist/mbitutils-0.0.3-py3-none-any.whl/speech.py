"""
Author: Øivind Rønning, Statped
Github: https://github.com/oivron/mbitutils
"""

class __Speech:
    """Speech synthesis"""

    def __init__(self):
        """Init"""
    
    def say(self, text):
        """Read aloud selected text."""
    
speech = __Speech()